

const botname = '';
const oauth = '';
const twitch_channel = '';
const alert_cost = 5;
const post_value = 1;
const coins_greetings = 'ваш баланс составляет:';
const start_coins = 10;

module.exports.botname = botname;
module.exports.oauth = oauth;
module.exports.twitch_channel = twitch_channel;
module.exports.alert_cost = alert_cost;
module.exports.post_value = post_value;
module.exports.coins_greetings = coins_greetings;
module.exports.start_coins = start_coins;

