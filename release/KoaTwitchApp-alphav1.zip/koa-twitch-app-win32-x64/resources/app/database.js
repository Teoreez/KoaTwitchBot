const {alert_cost, post_value, start_coins} = require(__dirname+'/config')

const low = require('lowdb');
const FileSync = require('lowdb/adapters/FileSync');

const adapter = new FileSync('db.json')
const db = low(adapter)

// set defaults for DB
db.defaults({ users: [] })
  .write()


//functions
//check and update
function getCoins (twitch_name){
    const coins_data = db.get('users')
        .find({ username: twitch_name})
        .value();
    return coins_data.coins;
}
const coinsOperator = function(twitch_name) {
    if(getCoins(twitch_name) < alert_cost) {
        return false;
    } else {
        const take_cost = db.get('users')
        .find({ username: twitch_name })
        .update('coins', n => n - alert_cost)
        .write()
        take_cost;
        return true;
    }
}
const addCoins = function(twitch_name) {
    const addCoinsq = db.get('users')
    .find({ username: twitch_name})
    .update('coins', n => n + post_value)
    .write()
    addCoinsq;
}
const userOperator = function(twitch_name) {
    const finduser = db.get('users')
    .find({ username: twitch_name})
    .value()
    console.log(finduser);
    
    if(finduser === undefined) {
        db.get('users')
        .push({username: twitch_name, coins: start_coins})
        .write()
        //console.log('user created: ' + twitch_name);
    } else {
        addCoins(twitch_name);
        //console.log('coins added');
    }

}

module.exports.getCoins = getCoins;
module.exports.coinsOperator = coinsOperator;
module.exports.userOperator = userOperator;

