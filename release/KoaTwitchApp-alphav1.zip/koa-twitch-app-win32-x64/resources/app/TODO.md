TODO:

## Added

> Coins system


## TODO

> Better OOP
> Youtube and Mixer integration
> GUI
> Output chat as BS item
> Event log at GUI: Chat, Donation, Events

electron-packager .
