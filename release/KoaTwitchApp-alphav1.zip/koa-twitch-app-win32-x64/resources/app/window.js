
const { ipcRenderer } = require('electron');


ipcRenderer.on('list-content', (event, arg) => {
    console.log(arg)
    document.getElementById('data').textContent = arg.replace(/.mp3/gi, "").replace(/.mp4/gi, "").replace(/,/gi, ", ");
})
ipcRenderer.send('list-content', 'ping')

